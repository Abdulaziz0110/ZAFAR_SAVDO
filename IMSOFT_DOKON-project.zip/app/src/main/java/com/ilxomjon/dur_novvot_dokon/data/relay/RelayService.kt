package com.ilxomjon.dur_novvot_dokon.data.relay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ilxomjon.dur_novvot_dokon.R
import com.ilxomjon.dur_novvot_dokon.core.AppRole
import com.ilxomjon.dur_novvot_dokon.core.ServiceLocator
import com.ilxomjon.dur_novvot_dokon.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Admin: agentlar ko'prigi fonda (bildirishnoma bilan). Agent yangi narsa yozsa (g/{kalit}/sig) Firebase oqimi orqali
 * darhol bilib oladi; har 60 soniyada ham tekshiradi. Faqat Admin ilovada e'lon qilingan (admin flavor manifesti).
 */
class RelayService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wake = Channel<Unit>(Channel.CONFLATED)
    /** v5.1.1: 2-ilova buyurtma yozishi bilan (Firebase oqimi) — darhol tekshirish. */
    private val orderWake = Channel<Unit>(Channel.CONFLATED)
    private val orderStreams = HashMap<String, kotlinx.coroutines.Job>()
    private var lock: PowerManager.WakeLock? = null
    private var lastText = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ServiceLocator.ensureInit(applicationContext)
        startAsForeground(getString(R.string.rl_notif_starting))
        lock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "imsoft:relay").apply { setReferenceCounted(false); acquire() }
        scope.launch { mainLoop() }
        scope.launch { streamLoop() }
        scope.launch { orderStreamsLoop() }
        scope.launch { orderLoop() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!AppRole.isAdmin || !ServiceLocator.shareStore.relayOn) {
            stopSelf()
            return START_NOT_STICKY
        }
        wake.trySend(Unit)
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { lock?.release() }
        super.onDestroy()
    }

    private suspend fun mainLoop() {
        val host = ServiceLocator.relayHost
        val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull().orEmpty()
        var tickAt = 0L
        while (scope.isActive) {
            val st = ServiceLocator.shareStore
            // v3.4: agentlar ko'prigi o'chiq bo'lsa ham 2-ilova xizmati (so'rovlarga javob, qarz, 1C tarixi) ishlaydi
            if (!st.relayOn && !st.isConfigured) { stopSelf(); return }
            if (st.relayOn) {
                if (st.isCloudReady && st.agentKey.isEmpty()) st.agentKey = uz.imsoft.shared.CloudDb.newKey()
                runCatching { host.pump(version = version) }
            }
            // v3.1: kompyuterdan kelganlar, 2-ilova so'rovlari (qarzni yangilash) va yuborish — v3.4: har 25 soniyada
            if (System.currentTimeMillis() - tickAt >= 25_000L) {
                tickAt = System.currentTimeMillis()
                runCatching { ServiceLocator.share.tick() }
            }
            val s = host.stats
            val time = if (s.at > 0) SimpleDateFormat("HH:mm", Locale.US).format(Date(s.at)) else "—"
            update(if (s.error.isNotEmpty()) getString(R.string.rl_notif_error, time) else getString(R.string.rl_notif_ok, time, s.written))
            withTimeoutOrNull(25_000L) { wake.receive() }
        }
    }

    /**
     * v5.1.1: 2-ilova buyurtma yozgan zahoti bilish. Har mijozning s/{kalit}/ord joyida oxirgi bitta yozuv kuzatiladi
     * (orderBy="$key"&limitToLast=1 — indeks kerak emas, trafik juda kichik). Mijozlar ro'yxati o'zgarsa — moslashadi.
     */
    private suspend fun orderStreamsLoop() {
        while (scope.isActive) {
            val st = ServiceLocator.shareStore
            val keys = if (st.isCloudReady && st.acceptOrders) {
                runCatching { st.clients().map { it.readKey }.filter { it.length >= 24 }.take(6).toSet() }.getOrDefault(emptySet())
            } else {
                emptySet()
            }
            for ((k, job) in orderStreams.toList()) {
                if (k !in keys || job.isCompleted) { job.cancel(); orderStreams.remove(k) }
            }
            for (k in keys) {
                if (orderStreams[k] != null) continue
                orderStreams[k] = scope.launch {
                    sseLoop(mapOf("orderBy" to "\"${'$'}key\"", "limitToLast" to "1")) { "s/$k/ord" }
                }
            }
            delay(60_000L)
        }
    }

    /** Oqimdan signal kelganda (yoki har 2 daqiqada) buyurtmalarni tekshirib, yangisi bo'lsa bildirishnoma beradi. */
    private suspend fun orderLoop() {
        var lastAt = 0L
        while (scope.isActive) {
            withTimeoutOrNull(120_000L) { orderWake.receive() }
            val st = ServiceLocator.shareStore
            if (!st.acceptOrders || !st.isCloudReady) continue
            val now = System.currentTimeMillis()
            if (now - lastAt < 3_000L) continue
            lastAt = now
            runCatching { ServiceLocator.share.refreshOrders(notify = true) }
                .onFailure { if (it is kotlinx.coroutines.CancellationException) throw it }
        }
    }

    /** Bitta yo'lni Firebase oqimi (SSE) bilan kuzatish: put/patch kelsa [orderWake] uyg'onadi. */
    private suspend fun sseLoop(query: Map<String, String>, path: () -> String) {
        var backoff = 2_000L
        while (scope.isActive) {
            val st = ServiceLocator.shareStore
            if (!st.isCloudReady) { delay(30_000L); continue }
            try {
                val db = uz.imsoft.shared.CloudDb(st.dbUrl, st.secret)
                val c = URL(db.url(path(), query)).openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "text/event-stream")
                c.connectTimeout = 15_000
                c.readTimeout = 120_000
                try {
                    if (c.responseCode != 200) throw java.io.IOException("SSE HTTP ${c.responseCode}")
                    backoff = 2_000L
                    BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { r ->
                        var first = true
                        while (scope.isActive) {
                            val line = r.readLine() ?: break
                            if (!line.startsWith("event:")) continue
                            val ev = line.substringAfter(':').trim()
                            if (ev == "cancel" || ev == "auth_revoked") break
                            // Ulanishdagi birinchi "put" — bor ma'lumot, yangilik emas.
                            if (ev == "put" || ev == "patch") {
                                if (first && ev == "put") first = false else orderWake.trySend(Unit)
                            }
                        }
                    }
                } finally {
                    c.disconnect()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // internet yo'q — keyinroq; asosiy sikl baribir buyurtmalarni tekshiradi
            }
            delay(backoff)
            backoff = minOf(backoff * 2, 60_000L)
        }
    }

    /** Firebase oqimi (SSE): agent signal yozsa — darhol ishlash. */
    private suspend fun streamLoop() {
        var backoff = 2_000L
        while (scope.isActive) {
            val st = ServiceLocator.shareStore
            val key = st.agentKey
            if (!st.isCloudReady || key.isEmpty()) { delay(30_000L); continue }
            try {
                val db = uz.imsoft.shared.CloudDb(st.dbUrl, st.secret)
                val c = URL(db.url("g/$key/sig")).openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "text/event-stream")
                c.connectTimeout = 15_000
                c.readTimeout = 90_000
                try {
                    if (c.responseCode != 200) throw java.io.IOException("SSE HTTP ${c.responseCode}")
                    backoff = 2_000L
                    BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { r ->
                        while (scope.isActive) {
                            val line = r.readLine() ?: break
                            if (line.startsWith("event:")) {
                                val ev = line.substringAfter(':').trim()
                                if (ev == "put" || ev == "patch") wake.trySend(Unit)
                                if (ev == "cancel" || ev == "auth_revoked") break
                            }
                        }
                    }
                } finally {
                    c.disconnect()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // internet yo'q — keyinroq; asosiy sikl baribir har 60 s ishlaydi
            }
            delay(backoff)
            backoff = minOf(backoff * 2, 60_000L)
        }
    }

    private fun startAsForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notification(text), type)
        lastText = text
    }

    private fun update(text: String) {
        if (text == lastText) return
        lastText = text
        runCatching { getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text)) }
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.rl_channel), NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_sync)
            .setContentTitle(getString(R.string.rl_title)).setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(open).build()
    }

    companion object {
        private const val CHANNEL = "relay"
        private const val NOTIF_ID = 7301
        private const val WORK = "relay_periodic"

        /** Ko'prikni yoqish (faqat Admin, ilova ochiq paytida — fon cheklovlari). */
        fun start(ctx: Context) {
            if (!AppRole.isAdmin) return
            ServiceLocator.shareStore.relayOn = true
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, RelayService::class.java)) }
            schedule(ctx)
        }

        fun stop(ctx: Context) {
            ServiceLocator.shareStore.relayOn = false
            ctx.stopService(Intent(ctx, RelayService::class.java))
            runCatching { WorkManager.getInstance(ctx).cancelUniqueWork(WORK) }
        }

        /** Ilova ochilganda / telefon yonganda: yoqilgan (standart) va Firebase sozlangan bo'lsa ishlab tursin. */
        fun ensureRunning(ctx: Context) {
            val st = ServiceLocator.shareStore
            if (AppRole.isAdmin && st.isCloudReady && (st.relayOn || st.isConfigured)) start(ctx)
        }

        /** Zaxira: xizmat to'xtatilgan bo'lsa ham 15 daqiqada bir navbat ishlanadi. */
        fun schedule(ctx: Context) {
            runCatching {
                val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                    WORK, ExistingPeriodicWorkPolicy.KEEP,
                    PeriodicWorkRequestBuilder<RelayWorker>(15, TimeUnit.MINUTES).setConstraints(net).build(),
                )
            }
        }
    }
}

/** Fon zaxirasi: 15 daqiqada bir [RelayHost.pump]. */
class RelayWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        ServiceLocator.ensureInit(applicationContext)
        if (!AppRole.isAdmin || !ServiceLocator.shareStore.relayOn) return Result.success()
        runCatching { ServiceLocator.relayHost.pump() }
        return Result.success()
    }
}

/** Telefon qayta yoqilganda ko'prikni tiklash (Admin). */
class RelayBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        ServiceLocator.ensureInit(context.applicationContext)
        RelayService.ensureRunning(context.applicationContext)
    }
}
