/* v5.4 kassa: logic.js testlari (node). Kutilgan qiymatlar kassa_core.py dan olingan — ikkisi bir xil hisoblashi shart. */
'use strict';
const assert = require('assert');
const path = require('path');
const L = require(path.join(__dirname, 'kassa', 'logic.js'));

const CASES = [{"g": {"u": 0, "p": [2.675, 12345.5, 1.005, 2.675], "v": [5e-05, 10, 10, 2.675]}, "pt": "Цена4", "rate": 12700, "price": 268, "q": "1.5", "milli": 1500, "sum": 402}, {"g": {"u": 0, "p": [1500, 1000, 12345.5, 99999], "v": [5e-05, 1.2345, 0.105, 2.675]}, "pt": "Цена2", "rate": 12700, "price": 100000, "q": "1", "milli": 1000, "sum": 100000}, {"g": {"u": 0, "p": [99999, 12345.5, 1500, 1.005], "v": [5e-05, 0.105, 1.2345, 5e-05]}, "pt": "Цена2", "rate": 12700, "price": 1234550, "q": "0.0005", "milli": 1, "sum": 1235}, {"g": {"u": 0, "p": [1500, 1500, 1000, 1.005], "v": [0.5, 1.2345, 5e-05, 1.2345]}, "pt": "Цена2", "rate": 12650.55, "price": 150000, "q": "0.333", "milli": 333, "sum": 49950}, {"g": {"u": 1, "p": [1500, 0.105, 2.675, 2.675], "v": [1.2345, 1.2345, 10, 1.2345]}, "pt": "Цена3", "rate": 1.005, "price": 1005, "q": "1", "milli": 1000, "sum": 1005}, {"g": {"u": 1, "p": [1500, 1500, 12345.5, 1000], "v": [3.33335, 3.33335, 5e-05, 2.675]}, "pt": "Цена3", "rate": 12700, "price": 127, "q": "1", "milli": 1000, "sum": 127}, {"g": {"u": 1, "p": [1.005, 12345.5, 99999, 2.675], "v": [3.33335, 1.2345, 0.105, 0.105]}, "pt": "Цена1", "rate": 12650.55, "price": 4216934, "q": "0.333", "milli": 333, "sum": 1404239}, {"g": {"u": 0, "p": [1000, 2.675, 12345.5, 1.005], "v": [0.105, 0.5, 2.675, 5e-05]}, "pt": "Цена3", "rate": 1.005, "price": 1234550, "q": "2.675", "milli": 2675, "sum": 3302421}, {"g": {"u": 0, "p": [1000, 99999, 1000, 2.675], "v": [1.2345, 2.675, 1.2345, 0.5]}, "pt": "Цена4", "rate": 12650.55, "price": 268, "q": "0.333", "milli": 333, "sum": 89}, {"g": {"u": 0, "p": [0.105, 12345.5, 1.005, 99999], "v": [0.5, 2.675, 10, 5e-05]}, "pt": "Цена3", "rate": 12888.8888, "price": 101, "q": "1", "milli": 1000, "sum": 101}, {"g": {"u": 1, "p": [1000, 1500, 12345.5, 0.105], "v": [2.675, 3.33335, 1.2345, 3.33335]}, "pt": "Цена1", "rate": 12888.8888, "price": 3447778, "q": "0.333", "milli": 333, "sum": 1148110}, {"g": {"u": 0, "p": [12345.5, 1500, 1.005, 1000], "v": [10, 1.2345, 10, 10]}, "pt": "Цена4", "rate": 12888.8888, "price": 100000, "q": "1.5", "milli": 1500, "sum": 150000}, {"g": {"u": 0, "p": [1000, 0.105, 0.105, 99999], "v": [0.5, 1.2345, 10, 2.675]}, "pt": "Цена3", "rate": 12888.8888, "price": 11, "q": "2.675", "milli": 2675, "sum": 29}, {"g": {"u": 0, "p": [1500, 1000, 2.675, 1000], "v": [5e-05, 0.105, 3.33335, 5e-05]}, "pt": "Цена2", "rate": 12650.55, "price": 100000, "q": "12.3456", "milli": 12346, "sum": 1234600}, {"g": {"u": 0, "p": [1500, 2.675, 1.005, 99999], "v": [0.5, 1.2345, 0.105, 3.33335]}, "pt": "Цена1", "rate": 12650.55, "price": 150000, "q": "2.675", "milli": 2675, "sum": 401250}, {"g": {"u": 1, "p": [99999, 0.105, 1.005, 1500], "v": [2.675, 0.105, 0.105, 10]}, "pt": "Цена4", "rate": 12888.8888, "price": 12888889, "q": "0.333", "milli": 333, "sum": 4292000}, {"g": {"u": 1, "p": [99999, 1500, 1000, 99999], "v": [5e-05, 2.675, 1.2345, 10]}, "pt": "Цена3", "rate": 1.005, "price": 124, "q": "1.5", "milli": 1500, "sum": 186}, {"g": {"u": 1, "p": [12345.5, 0.105, 1.005, 0.105], "v": [5e-05, 2.675, 3.33335, 0.5]}, "pt": "Цена1", "rate": 12888.8888, "price": 129, "q": "0.333", "milli": 333, "sum": 43}, {"g": {"u": 1, "p": [2.675, 2.675, 12345.5, 1.005], "v": [0.105, 3.33335, 5e-05, 10]}, "pt": "Цена3", "rate": 12888.8888, "price": 129, "q": "12.3456", "milli": 12346, "sum": 1593}, {"g": {"u": 1, "p": [1.005, 1000, 99999, 0.105], "v": [5e-05, 3.33335, 3.33335, 10]}, "pt": "Цена4", "rate": 12888.8888, "price": 12888889, "q": "0.333", "milli": 333, "sum": 4292000}, {"g": {"u": 0, "p": [2.675, 2.675, 1.005, 12345.5], "v": [3.33335, 3.33335, 10, 3.33335]}, "pt": "Цена3", "rate": 1.005, "price": 101, "q": "1.5", "milli": 1500, "sum": 152}, {"g": {"u": 0, "p": [2.675, 99999, 12345.5, 12345.5], "v": [2.675, 1.2345, 2.675, 1.2345]}, "pt": "Цена3", "rate": 12650.55, "price": 1234550, "q": "2.675", "milli": 2675, "sum": 3302421}, {"g": {"u": 1, "p": [1000, 2.675, 2.675, 2.675], "v": [0.105, 1.2345, 2.675, 5e-05]}, "pt": "Цена3", "rate": 1.005, "price": 269, "q": "0.0005", "milli": 1, "sum": 0}, {"g": {"u": 0, "p": [1.005, 2.675, 12345.5, 2.675], "v": [0.5, 1.2345, 1.2345, 2.675]}, "pt": "Цена2", "rate": 1.005, "price": 268, "q": "1.5", "milli": 1500, "sum": 402}, {"g": {"u": 0, "p": [1500, 2.675, 2.675, 1000], "v": [0.105, 1.2345, 1.2345, 0.5]}, "pt": "Цена1", "rate": 12650.55, "price": 150000, "q": "0.333", "milli": 333, "sum": 49950}, {"g": {"u": 0, "p": [99999, 1500, 0.105, 1000], "v": [0.105, 0.105, 3.33335, 0.105]}, "pt": "Цена2", "rate": 12700, "price": 150000, "q": "1.5", "milli": 1500, "sum": 225000}, {"g": {"u": 0, "p": [12345.5, 1000, 12345.5, 99999], "v": [3.33335, 5e-05, 0.105, 5e-05]}, "pt": "Цена3", "rate": 12700, "price": 1234550, "q": "1", "milli": 1000, "sum": 1234550}, {"g": {"u": 0, "p": [12345.5, 1000, 12345.5, 0.105], "v": [2.675, 3.33335, 2.675, 3.33335]}, "pt": "Цена2", "rate": 12888.8888, "price": 100000, "q": "2.675", "milli": 2675, "sum": 267500}, {"g": {"u": 1, "p": [0.105, 2.675, 0.105, 12345.5], "v": [0.105, 1.2345, 1.2345, 2.675]}, "pt": "Цена4", "rate": 1.005, "price": 269, "q": "1.5", "milli": 1500, "sum": 404}, {"g": {"u": 0, "p": [0.105, 1000, 12345.5, 1.005], "v": [10, 0.5, 0.105, 0.5]}, "pt": "Цена2", "rate": 12888.8888, "price": 100000, "q": "0.333", "milli": 333, "sum": 33300}, {"g": {"u": 0, "p": [0.105, 99999, 99999, 99999], "v": [1.2345, 0.105, 3.33335, 0.105]}, "pt": "Цена4", "rate": 1.005, "price": 9999900, "q": "1.5", "milli": 1500, "sum": 14999850}, {"g": {"u": 0, "p": [12345.5, 2.675, 12345.5, 99999], "v": [3.33335, 0.105, 0.5, 3.33335]}, "pt": "Цена4", "rate": 12888.8888, "price": 9999900, "q": "0.333", "milli": 333, "sum": 3329967}, {"g": {"u": 1, "p": [1000, 1000, 2.675, 0.105], "v": [0.105, 1.2345, 3.33335, 0.5]}, "pt": "Цена4", "rate": 12650.55, "price": 632528, "q": "1", "milli": 1000, "sum": 632528}, {"g": {"u": 1, "p": [0.105, 12345.5, 1500, 99999], "v": [5e-05, 0.5, 1.2345, 0.105]}, "pt": "Цена2", "rate": 12888.8888, "price": 644444, "q": "12.3456", "milli": 12346, "sum": 7956306}, {"g": {"u": 0, "p": [12345.5, 99999, 0.105, 99999], "v": [2.675, 10, 5e-05, 2.675]}, "pt": "Цена1", "rate": 12700, "price": 1234550, "q": "1.5", "milli": 1500, "sum": 1851825}, {"g": {"u": 1, "p": [0.105, 2.675, 12345.5, 0.105], "v": [3.33335, 10, 2.675, 0.5]}, "pt": "Цена3", "rate": 1.005, "price": 269, "q": "0.333", "milli": 333, "sum": 90}, {"g": {"u": 0, "p": [1.005, 0.105, 1500, 1000], "v": [0.5, 3.33335, 2.675, 0.105]}, "pt": "Цена2", "rate": 12700, "price": 11, "q": "1", "milli": 1000, "sum": 11}, {"g": {"u": 1, "p": [1.005, 99999, 0.105, 0.105], "v": [10, 10, 10, 10]}, "pt": "Цена4", "rate": 1.005, "price": 1005, "q": "2.675", "milli": 2675, "sum": 2688}, {"g": {"u": 1, "p": [1.005, 2.675, 1500, 12345.5], "v": [0.105, 5e-05, 5e-05, 0.5]}, "pt": "Цена1", "rate": 12888.8888, "price": 135333, "q": "12.3456", "milli": 12346, "sum": 1670821}, {"g": {"u": 0, "p": [0.105, 12345.5, 2.675, 1.005], "v": [0.105, 3.33335, 1.2345, 1.2345]}, "pt": "Цена4", "rate": 1.005, "price": 101, "q": "0.333", "milli": 333, "sum": 34}];
const SCANS = [["2900123012345", false, ["2900123", 1234, true]], ["2800555031234", true, ["2800555", 3000, false]], ["2800555000071", false, ["2800555", 7000, false]], ["2112345", false, ["2112345", 1000, false]], ["2512345678901", false, ["251234567890", 1000, false]], [" 4780012345678 ", false, ["4780012345678", 1000, false]], ["0012345", false, ["0012345", 1000, false]], ["ab12-03", false, ["1203", 1000, false]], ["", false, ["", 0, false]], ["000", false, ["000", 1000, false]]];


for (const c of CASES) {
  const p = L.priceOf(c.g, c.pt, c.rate);
  assert.strictEqual(p, c.price, 'narx ' + JSON.stringify(c));
  const m = L.milli(c.q);
  assert.strictEqual(m, c.milli, 'miqdor ' + c.q);
  assert.strictEqual(L.lineSum(p, m), c.sum, 'summa ' + JSON.stringify(c));
}
for (const s of SCANS) {
  const r = L.parseScan(s[0], s[1]);
  assert.deepStrictEqual([r.code, r.milli, r.weighted], s[2], 'shtrix ' + s[0]);
}

// to'lov (kassa_core.settle bilan bir xil)
let r = L.settle(950000, 0, 1000000, 0, 0, false, false);
assert.deepStrictEqual([r.cash, r.change, r.debt], [950000, 50000, 0]);
assert.ok(L.settle(950000, 0, 0, 1000000, 0, false, false).e);
assert.ok(L.settle(1000000, 0, 400000, 0, 0, false, false).e);
r = L.settle(1000000, 100000, 400000, 200000, 0, true, false);
assert.deepStrictEqual([r.due, r.debt], [900000, 300000]);
r = L.settle(0, 0, 5000000, 0, 0, true, false);
assert.strictEqual(r.debt, -5000000);
assert.ok(L.settle(0, 0, 0, 0, 0, true, false).e);
r = L.settle(100000, 100000, 0, 0, 0, true, false);
assert.deepStrictEqual([r.discount, r.due], [0, 100000]);
assert.ok(L.settle(300000, 0, 100000, 0, 0, false, true).e);
assert.strictEqual(L.settle(300000, 0, 300000, 0, 0, false, true).debt, 0);

// qoldiq
assert.deepStrictEqual(L.capQty(5000, 3, false), { milli: 3000, capped: true });
assert.deepStrictEqual(L.capQty(5000, -1, false), { milli: 0, capped: true });
assert.deepStrictEqual(L.capQty(5000, 3, true), { milli: 5000, capped: false });

// qidiruv: kod, narx, nom so'zlari
const G = [
  { c: '15', n: 'Olma qizil', u: 0, p: [6000, 5500, 0, 0], v: [0, 0, 0, 0] },
  { c: '150', n: 'Nok', u: 0, p: [9000, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '7', n: "Qizil olma ‘Fuji’", u: 1, p: [0, 0, 0, 0], v: [0.5, 0, 0, 0] }
];
assert.deepStrictEqual(L.search(G, '15', 'Цена1', 12000).map(g => g.c), ['15', '150']);
assert.deepStrictEqual(L.search(G, '6000', 'Цена1', 12000).map(g => g.c), ['15', '7']);
assert.deepStrictEqual(L.search(G, '5500', 'Цена2', 12000).map(g => g.c), ['15']);
assert.deepStrictEqual(L.search(G, 'olma qiz', 'Цена1', 12000).map(g => g.c), ['15', '7']);
assert.deepStrictEqual(L.search(G, "'fuji'", 'Цена1', 12000).map(g => g.c), ['7']);   // ‘ ’ ham ' deb qidiriladi
assert.deepStrictEqual(L.search(G, 'banan', 'Цена1', 12000).map(g => g.c), []);

// telefondagi qidiruv algoritmi: imlo xatolari, kirill/lotin, h/x q/k, klaviatura tartibi, raqamlar aniq
const F = [
  { c: '1', n: 'Pista Eron qovurilgan', u: 0, p: [1, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '2', n: 'Bodom Amerika', u: 0, p: [2, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '3', n: 'B Mayiz 134', u: 0, p: [3, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '4', n: 'Mayiz 120', u: 0, p: [4, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '5', n: "Xurmo O'g'il", u: 0, p: [5, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '6', n: 'Кешью жареный', u: 0, p: [6, 0, 0, 0], v: [0, 0, 0, 0] },
  { c: '7', n: 'Pista', u: 0, p: [7, 0, 0, 0], v: [0, 0, 0, 0], f: 40 }
];
const S = (q) => L.search(F, q, 'Цена1', 0).map(g => g.c);
assert.deepStrictEqual(S('pistta').slice(0, 2).sort(), ['1', '7']);          // ortiqcha harf
assert.deepStrictEqual(S('psita').slice(0, 2).sort(), ['1', '7']);           // harflar almashgan
assert.strictEqual(S('pista')[0], '7');                                        // aniq + ko'p sotiladi
assert.strictEqual(S('badom')[0], '2');                                        // unli xato
assert.strictEqual(S('писта')[0], '7');                                        // kirillda yozilsa
assert.strictEqual(S('keshyu')[0], '6');                                       // nomi kirillda, qidiruv lotinda
assert.deepStrictEqual(S('ьфнша').sort(), ['3', '4']);                       // klaviatura tartibi adashgan
assert.strictEqual(S('ogil')[0], '5');                                         // tutuq belgisisiz
assert.strictEqual(S('hurmo')[0], '5');                                        // h ~ x
assert.deepStrictEqual(S('mayiz 134'), ['3']);                                 // 134 hech qachon 120 emas
assert.strictEqual(S('eron pista')[0], '1');                                   // so'zlar istalgan tartibda
assert.deepStrictEqual(S('qqqqzzz'), []);
const CL = [['10', 'Alisher aka', '+998 90 123 45 67', 0, 0, 0], ['11', 'Олим Тошкент', '', 0, 0, 0]];
assert.deepStrictEqual(L.searchClients(CL, 'alishir').map(c => c[0]), ['10']);
assert.deepStrictEqual(L.searchClients(CL, 'olim').map(c => c[0]), ['11']);
assert.deepStrictEqual(L.searchClients(CL, '4567').map(c => c[0]), ['10']);
assert.strictEqual(L.osa('ab', 'ba', 2), 1);

// ko'rinish va yuborish matnlari
assert.strictEqual(L.fmtMoney(123456700), '1 234 567');
assert.strictEqual(L.fmtMoney(12345), '123,45');
assert.strictEqual(L.fmtMoney(-5000), '−50');
assert.strictEqual(L.fmtQty(1500), '1,5');
assert.strictEqual(L.fmtQty(2000), '2');
assert.strictEqual(L.centsText(635000), '6350.00');
assert.strictEqual(L.centsText(5), '0.05');
assert.strictEqual(L.milliText(1234), '1.234');
assert.ok(/^k[a-z0-9]{20,40}$/.test(L.newId()));
assert.strictEqual(L.cents('1 234,5'), 123450);
assert.strictEqual(L.cents('abc'), 0);

console.log('kassa logic: OK (' + CASES.length + ' narx, ' + SCANS.length + ' shtrix)');

