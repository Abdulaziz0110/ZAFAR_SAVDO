package com.ilxomjon.dur_novvot_dokon.data.onec

import android.content.Context
import com.ilxomjon.dur_novvot_dokon.data.share.ShareStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import uz.imsoft.shared.CloudDb
import uz.imsoft.shared.JObj
import uz.imsoft.shared.Json
import uz.imsoft.shared.onec.OneCCodec
import uz.imsoft.shared.onec.OneCSales
import uz.imsoft.shared.onec.Suppliers
import uz.imsoft.shared.onec.WriteCodec
import uz.imsoft.shared.onec.WriteKind
import uz.imsoft.shared.onec.WriteRequest
import uz.imsoft.shared.onec.WriteResult
import java.io.File

/** Admin'dagi 1C yozuvi: so'rov va (kelgan bo'lsa) kompyuter natijasi. "Kiritildi" faqat natija ok bo'lsa. */
data class WriteItem(val req: WriteRequest, val sentAt: Long, val result: WriteResult? = null, val sendError: String = "") {
    val isDone: Boolean get() = result?.ok == true && result.state != WriteResult.UNDONE
    val isFinal: Boolean get() = result != null
}

data class OneCState(
    val sales: OneCSales? = null,
    val suppliers: Suppliers? = null,
    val writes: List<WriteItem> = emptyList(),
    val requestedAt: Long = 0L,
    val requestedKind: String = "",
)

/**
 * v3.2 Admin: kompyuter yuborgan 1C savdolar ro'yxati va ta'minotchilar (faqat o'qish) hamda "Tasdiqlab kiritish"
 * navbati (w/{inbox}). Ma'lumot telefonda saqlanadi — internet bo'lmasa ham oxirgisi ko'rinadi.
 */
class OneCRepository(private val context: Context, private val store: ShareStore) {
    private val _state = MutableStateFlow(OneCState())
    val state: StateFlow<OneCState> = _state.asStateFlow()
    private val mutex = Mutex()
    @Volatile private var loaded = false

    private fun dir() = File(context.filesDir, "onec").apply { mkdirs() }
    private fun cloud() = CloudDb(store.dbUrl, store.secret)
    private val inbox: String get() = store.inboxKey

    val ready: Boolean get() = store.isCloudReady && inbox.isNotEmpty()

    suspend fun load() = mutex.withLock {
        if (loaded) return@withLock
        withContext(Dispatchers.IO) {
            val sales = runCatching { File(dir(), "sales.json").takeIf { it.isFile }?.readBytes()?.let(OneCCodec::parseSales) }.getOrNull()
            val supp = runCatching { File(dir(), "supp.json").takeIf { it.isFile }?.readBytes()?.let(OneCCodec::parseSuppliers) }.getOrNull()
            _state.value = _state.value.copy(sales = sales, suppliers = supp, writes = readWrites())
        }
        loaded = true
    }

    /** Kompyuterdan kelgan fayl (ShareRepository.processInbox chaqiradi). */
    suspend fun onData(kind: String, bytes: ByteArray): Boolean {
        load()
        return withContext(Dispatchers.IO) {
            when (kind) {
                "sales" -> {
                    val s = OneCCodec.parseSales(bytes)
                    File(dir(), "sales.json").writeBytes(bytes)
                    _state.value = _state.value.copy(sales = s)
                    true
                }
                "supp" -> {
                    val s = OneCCodec.parseSuppliers(bytes)
                    File(dir(), "supp.json").writeBytes(bytes)
                    _state.value = _state.value.copy(suppliers = s)
                    true
                }
                else -> false
            }
        }
    }

    /** "Shu davrni yuboring" (kompyuter keyingi aylanishda — 30 soniyagacha — bajaradi). [from]/[to] — yyyyMMdd. */
    suspend fun requestData(kind: String, from: String, to: String) {
        check(ready) { "cloud" }
        withContext(Dispatchers.IO) {
            cloud().put("p/$inbox/dreq", linkedMapOf("k" to kind, "f" to from, "t" to to, "at" to CloudDb.SERVER_TIME))
        }
        _state.value = _state.value.copy(requestedAt = System.currentTimeMillis(), requestedKind = kind)
    }

    // ---------------- 1C'ga yozish ----------------

    /** Egasi tasdiqlagan so'rovni navbatga qo'yadi. Internet bo'lmasa — xato (so'rov yo'qolmaydi, "Qayta yuborish" mumkin). */
    suspend fun submit(req: WriteRequest, by: String): WriteItem {
        load()
        require(req.problem() == null) { req.problem().orEmpty() }
        val item = WriteItem(req, System.currentTimeMillis())
        update { it.filter { w -> w.req.id != req.id } + item }
        return push(item)
    }

    private suspend fun push(item: WriteItem): WriteItem {
        val err = runCatching {
            check(ready) { "cloud" }
            withContext(Dispatchers.IO) { cloud().put("w/$inbox/${item.req.id}", WriteCodec.toCloud(item.req, "Admin")) }
        }.exceptionOrNull()
        val sent = item.copy(sendError = err?.message.orEmpty().take(200).ifEmpty { if (err != null) err.javaClass.simpleName else "" })
        update { l -> l.map { if (it.req.id == item.req.id) sent else it } }
        if (err != null && err is kotlinx.coroutines.CancellationException) throw err
        return sent
    }

    /** Yuborilmay qolganlarni qayta yuboradi. */
    suspend fun retryUnsent() {
        load()
        for (w in _state.value.writes.filter { it.sendError.isNotEmpty() && it.result == null }) push(w)
    }

    /** Xato bilan qaytgan yozuvni yangi id bilan qayta yuboradi. */
    suspend fun resend(id: String): WriteItem? {
        val w = _state.value.writes.firstOrNull { it.req.id == id } ?: return null
        return submit(w.req.copy(id = WriteCodec.newId(), at = System.currentTimeMillis()), "Admin")
    }

    /** Kiritilgan hujjatni bekor qilish (1C'da o'chirish belgisi). */
    suspend fun undo(id: String): WriteItem =
        submit(WriteRequest(WriteCodec.newId(), WriteKind.UNDO, System.currentTimeMillis(), target = id), "Admin")

    /** Kompyuter natijalarini o'qiydi (navbatdagi va oxirgi 2 kunda kiritilganlar — bekor qilinganini ham ko'rish uchun). */
    suspend fun refreshResults(): Int {
        load()
        if (!ready) return 0
        retryUnsent()
        val now = System.currentTimeMillis()
        val want = _state.value.writes.filter { it.sendError.isEmpty() && (it.result == null || (it.isDone && now - it.sentAt < 2 * 86_400_000L)) }
        if (want.isEmpty()) return 0
        val db = cloud()
        var changed = 0
        val results = HashMap<String, WriteResult>()
        withContext(Dispatchers.IO) {
            for (w in want) {
                val v = runCatching { db.get("wr/$inbox/${w.req.id}") }.getOrNull() ?: continue
                WriteCodec.resultFromCloud(w.req.id, v)?.let { results[w.req.id] = it }
            }
        }
        update { l ->
            l.map { w ->
                val r = results[w.req.id]
                if (r != null && r != w.result) { changed++; w.copy(result = r) } else w
            }
        }
        return changed
    }

    fun pendingCount(): Int = _state.value.writes.count { it.result == null }

    private suspend fun update(f: (List<WriteItem>) -> List<WriteItem>) = mutex.withLock {
        val l = f(_state.value.writes).sortedByDescending { it.sentAt }.take(500)
        _state.value = _state.value.copy(writes = l)
        withContext(Dispatchers.IO) { saveWrites(l) }
    }

    private fun writesFile() = File(dir(), "writes.json")

    private fun saveWrites(l: List<WriteItem>) {
        val arr = l.map { w ->
            linkedMapOf<String, Any?>(
                "id" to w.req.id, "k" to w.req.kind, "c" to w.req.at, "p" to WriteCodec.payload(w.req), "s" to w.sentAt, "se" to w.sendError,
                "r" to w.result?.let { r -> linkedMapOf("at" to r.at, "ok" to r.ok, "st" to r.state, "no" to r.number, "ref" to r.ref, "e" to r.error) },
            )
        }
        val tmp = File(dir(), "writes.json.tmp")
        tmp.writeText(Json.write(arr))
        tmp.renameTo(writesFile())
    }

    @Suppress("UNCHECKED_CAST")
    private fun readWrites(): List<WriteItem> = runCatching {
        val f = writesFile()
        if (!f.isFile) return emptyList()
        (Json.parse(f.readText()) as? List<Any?>).orEmpty().mapNotNull { x ->
            val o = JObj(x as? Map<String, Any?> ?: return@mapNotNull null)
            val req = WriteCodec.fromCloud(o.str("id"), mapOf("k" to o.str("k"), "p" to o.str("p"), "c" to o.long("c"))) ?: return@mapNotNull null
            val r = o.obj("r")?.let { WriteCodec.resultFromCloud(req.id, it.map) }
            WriteItem(req, o.long("s"), r, o.str("se"))
        }
    }.getOrDefault(emptyList())
}
